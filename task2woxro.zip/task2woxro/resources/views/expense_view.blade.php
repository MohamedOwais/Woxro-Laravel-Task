<!DOCTPE html>
<html>
<head>
  <title>Ledger Details</title>
</head>
<style>
  .tb { 
  	border-collapse: collapse;
  	margin-left: auto;
    margin-right: auto;
   }
  .tb th, .tb td { 
  	padding: 5px; 
  	border: solid 1px #777; 
  }
  .tb th {
    background-color: lightblue;
   }
</style>
<body >
	<table class="tb">
   <tr>
	  <th>Date of Transaction</th>
	  <th>Ledger</th>
    <th>Subledger</th>
    <th>Amount</th>
   </tr>
@foreach ($expenses as $expense)
  <tr>
	 <td>{{$expense->dateoftransaction}}</td>
     <td>{{$expense->ledger}}</td>
	 <td>{{ $expense->subledger }}</td>
	 <td>{{$expense->amount}}</td>
  </tr>
@endforeach
  </table>
</body>
</html>