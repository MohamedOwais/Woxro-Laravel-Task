<!DOCTPE html>
<html>
<head>
  <title>Ledger Details</title>
</head>
<style>
  .tb { 
  	border-collapse: collapse;
  	margin-left: auto;
    margin-right: auto;
   }
  .tb th, .tb td { 
  	padding: 5px; 
  	border: solid 1px #777; 
  }
  .tb th {
    background-color: lightblue;
   }
</style>
<body >
	<table class="tb">
   <tr>
	  <th>Code</th>
	  <th>Account</th>
      <th>Debit</th>
      <th>Credit</th>
   </tr>
@foreach ($ledgers as $ledger)
  <tr>
	 <td>{{ $ledger->ledgercode}}</td>
     <td>{{ $ledger->ledgername}}</td>
	 <td>{{ $ledger->debit }}</td>
	 <td>{{$ledger->credit}}</td>
    
  </tr>
@endforeach
  </table>
</body>
</html>