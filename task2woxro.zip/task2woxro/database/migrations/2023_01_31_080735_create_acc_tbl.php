<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccTbl extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('acc_tbl', function (Blueprint $table) {
            $table->increments('accounts_id');
            $table->date('date');
            $table->text('transaction_code');
            $table->text('cash_code');
            $table->text('ledger_code');
            $table->text('subLedger_code');
            $table->char('type');
            $table->float('amount');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('acc_tbl');
    }
}
