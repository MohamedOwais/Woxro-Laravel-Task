<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubledgerTbl extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subledger_tbl', function (Blueprint $table) {
            $table->increments('subledger_id');
            $table->text('ledger_code');
            $table->text('subledger_code');
            $table->char('subledger_name');
            $table->char('category');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subledger_tbl');
    }
}
