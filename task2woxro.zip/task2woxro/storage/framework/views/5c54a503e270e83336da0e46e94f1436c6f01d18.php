<!DOCTPE html>
<html>
<head>
  <title>Ledger Details</title>
</head>
<style>
  .tb { 
  	border-collapse: collapse;
  	margin-left: auto;
    margin-right: auto;
   }
  .tb th, .tb td { 
  	padding: 5px; 
  	border: solid 1px #777; 
  }
  .tb th {
    background-color: lightblue;
   }
</style>
<body >
	<table class="tb">
   <tr>
	  <th>Code</th>
	  <th>Account</th>
      <th>Debit</th>
      <th>Credit</th>
   </tr>
<?php $__currentLoopData = $ledgers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ledger): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
	 <td><?php echo e($ledger->ledgercode); ?></td>
     <td><?php echo e($ledger->ledgername); ?></td>
	 <td><?php echo e($ledger->debit); ?></td>
	 <td><?php echo e($ledger->credit); ?></td>
    
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\task2woxro\resources\views/ledger_view.blade.php ENDPATH**/ ?>