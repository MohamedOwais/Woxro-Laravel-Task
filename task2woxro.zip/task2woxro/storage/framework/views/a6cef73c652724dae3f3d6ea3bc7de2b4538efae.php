<!DOCTPE html>
<html>
<head>
  <title>Ledger Details</title>
</head>
<style>
  .tb { 
  	border-collapse: collapse;
  	margin-left: auto;
    margin-right: auto;
   }
  .tb th, .tb td { 
  	padding: 5px; 
  	border: solid 1px #777; 
  }
  .tb th {
    background-color: lightblue;
   }
</style>
<body >
	<table class="tb">
   <tr>
	  <th>Date of Transaction</th>
	  <th>Ledger</th>
    <th>Subledger</th>
    <th>Amount</th>
   </tr>
<?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
	 <td><?php echo e($expense->dateoftransaction); ?></td>
     <td><?php echo e($expense->ledger); ?></td>
	 <td><?php echo e($expense->subledger); ?></td>
	 <td><?php echo e($expense->amount); ?></td>
  </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
</body>
</html><?php /**PATH C:\xampp\htdocs\task2woxro\resources\views/expense_view.blade.php ENDPATH**/ ?>